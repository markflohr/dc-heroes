<?php 
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "dc-heroes";

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>dc heroes</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<header id="header">
  		<div id="logo-image">
  			<a href="index.php">
  				<img src="images/logo.png" width="100" height="100">
  			</a>
  		</div>
        <div id="logo-text">
            <a href="index.php">Heroes</a>
        </div>
        <div class="clearfix"></div>	
    </header>
	<div>
		<div id="teams">
			<?php
				$sql = "SELECT teamName FROM team"; 
				$result = $conn->query($sql);
			?>
		</div>
		<div id="heroes">
			<?php
				$sql = "SELECT heroName FROM hero"; 
				$result = $conn->query($sql);
			?>
		</div>
		<div id="hero-details">
			
		</div>
	</div>
</body>
</html>